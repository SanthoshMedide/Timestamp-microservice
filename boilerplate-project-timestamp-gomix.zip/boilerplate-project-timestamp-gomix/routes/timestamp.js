var express = require('express');
var router = express.Router();

router.get('/hello',function(request, response){
	response.json({greeting: 'hello API'});
});

router.get('/timestamp', function(req,res){
	var date = new Date();
	
	res.json({"unix": date.getTime(), "utc" : date.toUTCString() });
});


router.get('/timestamp/:date_string', function(req,res){
	var d = req.params.date_string;
	var timestamp = Date.parse(d);
	var date = new Date(timestamp);
	if(timestamp){
		
		res.json({"unix": date.getTime(), "utc" : date.toUTCString() });
	}
	else{
		res.json({"unix": date.getTime(), "utc" : date.toUTCString() });
	}
	
});

module.exports = router;